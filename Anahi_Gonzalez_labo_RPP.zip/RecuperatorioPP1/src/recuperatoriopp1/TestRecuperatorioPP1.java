
package recuperatoriopp1;

public class TestRecuperatorioPP1 {


    public static void main(String[] args) {
        Biblioteca b1 = new Biblioteca();
        
        Libro l1 = new Libro("100 años",1984, "Garcia Marquez", Genero.FICCION);
        
        
        b1.agregarPublicacion(l1);
        
        b1.mostrarPublicaciones();
    }
    
}
