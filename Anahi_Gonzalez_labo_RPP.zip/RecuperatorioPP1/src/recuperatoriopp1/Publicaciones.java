
package recuperatoriopp1;


public class Publicaciones {
    private String titulo;
    private int anioPublicacion;

    public Publicaciones(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }
    

    public String getTitulo() {
        return titulo;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    
    
}
