package recuperatoriopp1;


public interface Lectura {
   void leer(); 
}
