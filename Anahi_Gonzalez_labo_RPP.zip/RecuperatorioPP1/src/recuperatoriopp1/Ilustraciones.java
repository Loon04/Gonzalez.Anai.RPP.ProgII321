package recuperatoriopp1;

public class Ilustraciones extends Publicaciones{
    private String nombreIlustrador;
    private int ancho;
    private int alto;

    public Ilustraciones(String titulo, int anioPublicacion, String nombreIlustrador, int ancho, int alto) {
        super(titulo, anioPublicacion);
        this.nombreIlustrador = nombreIlustrador;
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public String toString() {
        return "Ilustraciones[ Ilustrador=" + nombreIlustrador + ", ancho=" + ancho + ", alto=" + alto + ']';
    }
    
    
}
