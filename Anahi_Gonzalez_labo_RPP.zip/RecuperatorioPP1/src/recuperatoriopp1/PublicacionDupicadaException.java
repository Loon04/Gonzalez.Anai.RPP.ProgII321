
package recuperatoriopp1;

public class PublicacionDupicadaException extends RuntimeException {
    private static final String MESSEGE = "La publicacion ya existe";
}
