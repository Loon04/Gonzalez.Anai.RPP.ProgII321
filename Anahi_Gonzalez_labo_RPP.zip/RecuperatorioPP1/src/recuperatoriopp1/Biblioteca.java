package recuperatoriopp1;

import java.util.ArrayList;


public class Biblioteca {
    private ArrayList<Publicaciones> publicaciones;

    public Biblioteca() {
        publicaciones = new ArrayList<>();
    }
    
    public void agregarPublicacion(Publicaciones publicacion){
        if (publicaciones.contains(publicacion)){
            throw new PublicacionDupicadaException();
        }
        publicaciones.add(publicacion);
    }
    
    public void mostrarPublicaciones(){
        for (Publicaciones pub : publicaciones){
            System.out.println(pub);
        }
        
    }
}

