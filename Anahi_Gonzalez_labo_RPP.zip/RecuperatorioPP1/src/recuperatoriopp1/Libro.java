
package recuperatoriopp1;


public class Libro extends Publicaciones implements Lectura{
    private String autor;
    private Genero genero;

    public Libro(String titulo, int anioPublicacion, String autor, Genero genero) {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    
    @Override
    public void leer(){
        System.out.println("Se esta leyendo un Libro");
    }

    @Override
    public String toString() {
        return "Libro [autor=" + autor + ", genero=" + genero + ']';
    }
    
    
}
